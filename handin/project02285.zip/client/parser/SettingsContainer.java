package client.parser;

import client.node.level.distancemap.DistanceMap;

	public class SettingsContainer{
		public DistanceMap dm;
		public boolean kcluster = true;
	}
