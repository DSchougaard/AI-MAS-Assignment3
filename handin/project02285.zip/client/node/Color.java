package client.node;

public enum Color{
	blue,red,green,cyan,magenta,orange,pink,yellow
}
